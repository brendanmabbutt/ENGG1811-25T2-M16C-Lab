my_variable = 3
affine_transformation = 2 * my_variable + 6

print("My affine is", affine_transformation, "meters") 