root_alpha = 5
root_beta = 4.2
root_gamma = 5
root_delta = 40.1
root_epsilon = -2
root_zeta = -2

# aligning to equal sign 
prod_of_roots = root_alpha * root_beta * root_gamma * root_delta \
                * root_epsilon * root_zeta