num_one = 5
num_two = 6
num_three = 7

my_average = (num_one + num_two + num_three) / 3
print(f"The average of my three numbers is {my_average}")