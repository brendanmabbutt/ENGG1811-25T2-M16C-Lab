#%%
# Look at the variable explorer when the following happens
x = 3
y = 4
z = x + y
my_data = x

food = "pizza"
five_pi = 3.1415

# notice the value of x after this line runs
x = x + 4

