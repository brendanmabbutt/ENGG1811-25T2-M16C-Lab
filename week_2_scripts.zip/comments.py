#%%
# Have a look at what is outputted in the console here

# print(1)
print(2)
# print(3)
# print(4)
print(5)
